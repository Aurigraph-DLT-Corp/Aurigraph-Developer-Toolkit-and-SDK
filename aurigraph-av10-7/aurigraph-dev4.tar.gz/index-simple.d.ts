import 'reflect-metadata';
//# sourceMappingURL=index-simple.d.ts.map