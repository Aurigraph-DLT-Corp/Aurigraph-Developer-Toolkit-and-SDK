export declare class AurigraphRWAPlatform {
    private app;
    private port;
    constructor(port?: number);
    private setupMiddleware;
    private setupRoutes;
    start(): Promise<void>;
    stop(): Promise<void>;
}
//# sourceMappingURL=index-rwa-simple.d.ts.map