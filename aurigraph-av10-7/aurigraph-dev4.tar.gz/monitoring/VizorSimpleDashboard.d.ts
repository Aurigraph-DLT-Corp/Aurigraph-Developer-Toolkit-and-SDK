export declare class VizorSimpleDashboard {
    private logger;
    private app;
    private server;
    private wss;
    private clients;
    constructor();
    private setupRoutes;
    start(port?: number): Promise<void>;
}
//# sourceMappingURL=VizorSimpleDashboard.d.ts.map