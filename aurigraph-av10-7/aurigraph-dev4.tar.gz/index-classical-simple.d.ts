/**
 * Aurigraph V10 - Classical CPU/GPU Version (Simplified)
 * Main entry point for high-performance blockchain platform without quantum computing
 */
export {};
//# sourceMappingURL=index-classical-simple.d.ts.map