/**
 * Aurigraph V10 - Classical CPU/GPU Version
 * Main entry point for high-performance blockchain platform without quantum computing
 */
export {};
//# sourceMappingURL=index-classical.d.ts.map