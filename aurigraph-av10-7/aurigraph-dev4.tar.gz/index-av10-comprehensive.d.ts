import 'reflect-metadata';
//# sourceMappingURL=index-av10-comprehensive.d.ts.map