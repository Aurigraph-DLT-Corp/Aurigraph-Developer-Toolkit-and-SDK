import 'reflect-metadata';
//# sourceMappingURL=index-deploy.d.ts.map