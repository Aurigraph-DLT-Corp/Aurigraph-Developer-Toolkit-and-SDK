import 'reflect-metadata';
//# sourceMappingURL=index.d.ts.map